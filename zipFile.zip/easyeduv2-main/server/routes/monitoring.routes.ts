import type { Express } from "express";
import { jwtAuthMiddleware } from "../auth";
import { getRecentErrors, getErrorStats } from "../lib/monitoring";

export function registerMonitoringRoutes(app: Express) {
  app.get("/api/admin/errors", jwtAuthMiddleware, (req, res) => {
    const limit = Math.min(parseInt((req.query.limit as string) || "50", 10), 200);
    const level = req.query.level as string | undefined;

    let events = getRecentErrors(limit);
    if (level === "error" || level === "warn") {
      events = events.filter(e => e.level === level);
    }

    return res.json({
      events,
      stats: getErrorStats(),
    });
  });
}
