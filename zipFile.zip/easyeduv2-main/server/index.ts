import dotenv from "dotenv";

// Preserve Replit-managed secrets before dotenv can override them.
// PGHOST is injected by Replit's database provisioning — if it's present,
// the Replit DATABASE_URL secret is already in process.env and must win.
const replitDbUrl = process.env.DATABASE_URL;
const replitPgHost = process.env.PGHOST;

dotenv.config({ override: false });

// If Replit had a DATABASE_URL before dotenv ran, restore it.
if (replitDbUrl && replitPgHost) {
  process.env.DATABASE_URL = replitDbUrl;
}
import express, { type Request, Response, NextFunction } from "express";
import cors from "cors";
import { registerRoutes } from "./routes";
import { serveStatic } from "./static";
import { createServer } from "http";
import { captureError } from "./lib/monitoring";

const app = express();
const httpServer = createServer(app);

declare module "http" {
  interface IncomingMessage {
    rawBody: unknown;
  }
}

app.use(cors({
  origin: true,
  credentials: true,
}));

app.use(
  express.json({
    verify: (req, _res, buf) => {
      req.rawBody = buf;
    },
  }),
);

app.use(express.urlencoded({ extended: false }));

export function log(message: string, source = "express") {
  const formattedTime = new Date().toLocaleTimeString("en-US", {
    hour: "numeric",
    minute: "2-digit",
    second: "2-digit",
    hour12: true,
  });

  console.log(`${formattedTime} [${source}] ${message}`);
}

app.use((req, res, next) => {
  const start = Date.now();
  const path = req.path;
  let capturedJsonResponse: Record<string, any> | undefined = undefined;

  const originalResJson = res.json;
  res.json = function (bodyJson, ...args) {
    capturedJsonResponse = bodyJson;
    return originalResJson.apply(res, [bodyJson, ...args]);
  };

  res.on("finish", () => {
    const duration = Date.now() - start;
    if (path.startsWith("/api")) {
      let logLine = `${req.method} ${path} ${res.statusCode} in ${duration}ms`;
      if (capturedJsonResponse) {
        logLine += ` :: ${JSON.stringify(capturedJsonResponse)}`;
      }

      log(logLine);
    }
  });

  next();
});

(async () => {
  await registerRoutes(httpServer, app);

  // ============================================================
  // SCHEMA CHANGE RULE — đọc trước khi thêm bất cứ thứ gì vào đây
  // ============================================================
  // Block này CHỈ dùng cho:
  //   ✅ App startup (routes, services, WS)
  //   ✅ Seeds (dữ liệu mặc định lần đầu)
  //   ✅ One-time data backfills (di chuyển data, không phải tạo cột)
  //   ✅ Service initialization (Tinode, cache, v.v.)
  //
  // KHÔNG được dùng cho:
  //   ❌ ALTER TABLE ... ADD COLUMN
  //   ❌ CREATE TABLE IF NOT EXISTS
  //   ❌ Bất kỳ DDL nào dù có bọc IF NOT EXISTS
  //
  // Nếu cần thêm bảng/cột mới:
  //   1. Cập nhật shared/schema.ts
  //   2. Chạy: npm run db:push  (hoặc drizzle-kit generate + migrate)
  //   3. KHÔNG thêm gì vào file này
  //
  // Xem thêm: replit.md > Schema Change Rule
  // ============================================================

  // Start Tinode admin WebSocket connection eagerly at server start
  try {
    const { tinodeAdmin } = await import("./lib/tinode-admin");
    tinodeAdmin.connect();
  } catch (err) {
    console.warn("[Tinode] Admin WS startup failed:", err);
  }

  // Migrate pipelineStage names → relationshipIds UUIDs
  try {
    const { storage: migrationStorage } = await import("./storage");
    await migrationStorage.migratePipelineStageToRelationshipIds();
  } catch (err) {
    console.error("Migration pipelineStage→relationshipIds failed:", err);
  }

  // Migrate content library schema (make programId/sessionNumber nullable, add createdBy)
  try {
    const { storage: migrationStorage } = await import("./storage");
    await migrationStorage.migrateContentLibrarySchema();
  } catch (err) {
    console.error("Migration content library schema failed:", err);
  }

  // Migrate session contents: backfill resourceUrl for records where it is null
  try {
    const { db, eq, isNull, and, sql: baseSql, sessionContents, classSessions, courseProgramContents } = await import("./storage/base");
    const nullContents = await db
      .select({
        id: sessionContents.id,
        title: sessionContents.title,
        contentType: sessionContents.contentType,
        classSessionId: sessionContents.classSessionId,
        programId: classSessions.programId,
      })
      .from(sessionContents)
      .innerJoin(classSessions, eq(sessionContents.classSessionId, classSessions.id))
      .where(and(isNull(sessionContents.resourceUrl), baseSql`${classSessions.programId} IS NOT NULL`));

    let fixed = 0;
    for (const sc of nullContents) {
      if (!sc.programId) continue;
      const matches = await db
        .select({ id: courseProgramContents.id })
        .from(courseProgramContents)
        .where(and(
          eq(courseProgramContents.programId, sc.programId),
          eq(courseProgramContents.title, sc.title),
          eq(courseProgramContents.type, sc.contentType),
        ))
        .limit(1);
      if (matches.length > 0) {
        await db.update(sessionContents).set({ resourceUrl: matches[0].id }).where(eq(sessionContents.id, sc.id));
        fixed++;
      }
    }
    if (fixed > 0) console.log(`Migration: backfilled resourceUrl for ${fixed} session content records`);
  } catch (err) {
    console.error("Migration session content resourceUrl backfill failed:", err);
  }

  // Seed default finance transaction categories
  try {
    const { db: seedDb } = await import("./storage/base");
    const { financeTransactionCategories } = await import("@shared/schema");
    const { eq, and } = await import("drizzle-orm");

    const defaultCategories = [
      { name: "Đặt cọc", type: "income" },
      { name: "Học phí", type: "income" },
      { name: "Kho", type: "income" },
      { name: "Chuyển lớp", type: "income" },
      { name: "Lương", type: "expense" },
      { name: "Kho", type: "expense" },
      { name: "Hoàn tiền", type: "expense" },
    ];

    for (const cat of defaultCategories) {
      const existing = await seedDb
        .select({ id: financeTransactionCategories.id })
        .from(financeTransactionCategories)
        .where(and(eq(financeTransactionCategories.name, cat.name), eq(financeTransactionCategories.type, cat.type)))
        .limit(1);
      if (existing.length === 0) {
        await seedDb.insert(financeTransactionCategories).values({ name: cat.name, type: cat.type as "income" | "expense", isDefault: true, isActive: true });
        console.log(`Seeded default ${cat.type} category: ${cat.name}`);
      }
    }
  } catch (err) {
    console.error("Failed to seed default finance categories:", err);
  }

  // Ensure questions table
  try {
    const { migrateQuestionsTable } = await import("./storage/question.storage");
    await migrateQuestionsTable();
  } catch (err) {
    console.error("Migration questions table failed:", err);
  }

  // Ensure exams table
  try {
    const { migrateExamsTable } = await import("./storage/exam.storage");
    await migrateExamsTable();
  } catch (err) {
    console.error("Migration exams table failed:", err);
  }

  // Ensure exam_sections table
  try {
    const { migrateExamSectionsTable } = await import("./storage/exam-section.storage");
    await migrateExamSectionsTable();
  } catch (err) {
    console.error("Migration exam_sections table failed:", err);
  }

  // Ensure exam_section_questions table
  try {
    const { migrateExamSectionQuestionsTable } = await import("./storage/exam-section-questions.storage");
    await migrateExamSectionQuestionsTable();
  } catch (err) {
    console.error("Migration exam_section_questions table failed:", err);
  }

  // Ensure exam_submissions table
  try {
    const { migrateExamSubmissionsTable } = await import("./storage/exam-submission.storage");
    await migrateExamSubmissionsTable();
  } catch (err) {
    console.error("Migration exam_submissions table failed:", err);
  }

  // Backfill: synchronise classes.start_date/end_date with actual schedule
  // (one-shot — no schema change, but data may be stale on rows created before
  // the recalculateClass cascade was added).
  try {
    const { db: migDb } = await import("./storage/base");
    const result: any = await migDb.execute(`
      WITH derived AS (
        SELECT
          c.id AS class_id,
          COALESCE(
            (SELECT MIN(sc.start_date) FROM student_classes sc WHERE sc.class_id = c.id),
            (SELECT MIN(cs.session_date) FROM class_sessions cs WHERE cs.class_id = c.id)
          ) AS new_start,
          COALESCE(
            (SELECT MAX(sc.end_date) FROM student_classes sc WHERE sc.class_id = c.id),
            (SELECT MAX(cs.session_date) FROM class_sessions cs WHERE cs.class_id = c.id)
          ) AS new_end
        FROM classes c
      )
      UPDATE classes c
         SET start_date = d.new_start,
             end_date   = d.new_end,
             updated_at = NOW()
        FROM derived d
       WHERE c.id = d.class_id
         AND (
              c.start_date IS DISTINCT FROM d.new_start
           OR c.end_date   IS DISTINCT FROM d.new_end
         )
    `);
    const fixed = (result as any).rowCount ?? 0;
    if (fixed > 0) console.log(`Migration: synced classes.start/end_date for ${fixed} classes`);
  } catch (err) {
    console.error("Migration classes start/end backfill failed:", err);
  }

  // Seed default departments and roles
  try {
    const { storage } = await import("./storage");
    const depts = await storage.getDepartments();
    if (depts.length === 0) {
      console.log("Seeding default departments and roles...");
      const deptCustomer = await storage.createDepartment({
        name: "Phòng Khách hàng",
        isSystem: true,
      });

      await storage.createRole({ name: "Học viên", departmentId: deptCustomer.id, isSystem: true });
      await storage.createRole({ name: "Phụ huynh", departmentId: deptCustomer.id, isSystem: true });

      const deptTraining = await storage.createDepartment({
        name: "Phòng Đào tạo",
        isSystem: true,
      });

      await storage.createRole({ name: "Giáo viên", departmentId: deptTraining.id, isSystem: true });
      await storage.createRole({ name: "Trợ giảng", departmentId: deptTraining.id, isSystem: true });
      console.log("Default departments and roles seeded.");
    }
  } catch (error) {
    console.error("Failed to seed default data:", error);
  }

  app.use((err: any, req: Request, res: Response, next: NextFunction) => {
    const status = err.status || err.statusCode || 500;
    const message = err.message || "Internal Server Error";

    captureError(err, {
      request: {
        method: req.method,
        path: req.path,
        statusCode: status,
        userId: (req.user as any)?.id,
        ip: req.ip,
      },
    });

    console.error("Internal Server Error:", err);

    if (res.headersSent) {
      return next(err);
    }

    return res.status(status).json({ message });
  });

  // importantly only setup vite in development and after
  // setting up all the other routes so the catch-all route
  // doesn't interfere with the other routes
  if (process.env.NODE_ENV === "production") {
    serveStatic(app);
  } else {
    const { setupVite } = await import("./vite");
    await setupVite(httpServer, app);
  }

  // ALWAYS serve the app on the port specified in the environment variable PORT
  // Other ports are firewalled. Default to 5000 if not specified.
  // this serves both the API and the client.
  // It is the only port that is not firewalled.
  const port = parseInt(process.env.PORT || "5000", 10);
  const listenOptions: any = {
    port,
    host: "0.0.0.0",
  };
  
  // reusePort is not supported on Windows
  if (process.platform !== "win32") {
    listenOptions.reusePort = true;
  }
  
  httpServer.listen(
    listenOptions,
    () => {
      log(`serving on port ${port}`);
    },
  );
})();
