import { useQuery } from "@tanstack/react-query";
import { api } from "@shared/routes";
import { STATIC_STALE_TIME } from "@/lib/queryClient";

  export interface CrmRelationship {
    id: string;
    name: string;
    color: string;
    position?: string;
  }

  export function useCrmRelationships() {
    return useQuery<CrmRelationship[]>({
      queryKey: [api.crm.relationships.list.path],
      queryFn: async () => {
        const res = await fetch(api.crm.relationships.list.path, { credentials: "include" });
        if (!res.ok) throw new Error("Failed to fetch CRM relationships");
        return await res.json();
      },
      staleTime: STATIC_STALE_TIME,
    });
  }

  export function useCrmCustomerSources() {
    return useQuery({
      queryKey: [api.crm.customerSources.list.path],
      queryFn: async () => {
        const res = await fetch(api.crm.customerSources.list.path, { credentials: "include" });
        if (!res.ok) throw new Error("Failed to fetch CRM customer sources");
        return await res.json();
      },
      staleTime: STATIC_STALE_TIME,
    });
  }

  export function useCrmRejectReasons() {
    return useQuery({
      queryKey: [api.crm.rejectReasons.list.path],
      queryFn: async () => {
        const res = await fetch(api.crm.rejectReasons.list.path, { credentials: "include" });
        if (!res.ok) throw new Error("Failed to fetch CRM reject reasons");
        return await res.json();
      },
      staleTime: STATIC_STALE_TIME,
    });
  }

  export interface CrmRequiredField { fieldKey: string; isRequired: boolean }

  export function useCrmRequiredFields() {
    return useQuery<CrmRequiredField[]>({
      queryKey: [api.crm.requiredFields.list.path],
      queryFn: async () => {
        const res = await fetch(api.crm.requiredFields.list.path, { credentials: "include" });
        if (!res.ok) throw new Error("Failed to fetch CRM required fields");
        return await res.json();
      },
      staleTime: STATIC_STALE_TIME,
    });
  }

  export interface CrmCustomField {
    id: string;
    label: string;
    fieldType: "text" | "number" | "date" | "textarea" | "select";
    options?: string[] | null;
    position: number;
    createdAt?: string;
    updatedAt?: string;
  }

  export function useCrmCustomFields() {
    return useQuery<CrmCustomField[]>({
      queryKey: [api.crm.customFields.list.path],
      queryFn: async () => {
        const res = await fetch(api.crm.customFields.list.path, { credentials: "include" });
        if (!res.ok) throw new Error("Failed to fetch CRM custom fields");
        return await res.json();
      },
      staleTime: STATIC_STALE_TIME,
    });
  }
  