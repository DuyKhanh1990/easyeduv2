import { useState, useEffect } from "react";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
  DialogDescription
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { AlertCircle, Clock } from "lucide-react";
import { useMutation, useQuery } from "@tanstack/react-query";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { ScrollArea } from "@/components/ui/scroll-area";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { format } from "date-fns";
import { vi } from "date-fns/locale";

interface ExcludeSessionsDialogProps {
  isOpen: boolean;
  onOpenChange: (open: boolean) => void;
  classId: string;
  currentSessionIndex?: number;
  classSessions: any[];
}

export function ExcludeSessionsDialog({
  isOpen,
  onOpenChange,
  classId,
  currentSessionIndex = 0,
  classSessions
}: ExcludeSessionsDialogProps) {
  const [fromSessionId, setFromSessionId] = useState<string>("");
  const [toSessionId, setToSessionId] = useState<string>("");
  const [reason, setReason] = useState<string>("");
  const [showWarning, setShowWarning] = useState(false);
  const { toast } = useToast();

  useEffect(() => {
    if (isOpen && classSessions.length > 0 && currentSessionIndex > 0) {
      const defaultSession = classSessions[Math.min(currentSessionIndex - 1, classSessions.length - 1)];
      if (defaultSession) {
        setFromSessionId(defaultSession.id);
        setToSessionId(defaultSession.id);
      }
    }
  }, [isOpen, currentSessionIndex, classSessions]);

  const checkAttendanceMutation = useMutation({
    mutationFn: async () => {
      const res = await apiRequest("POST", "/api/classes/check-attendance-for-exclusion", {
        classId,
        fromSessionId,
        toSessionId
      });
      return res.json();
    },
    onSuccess: (data) => {
      if (data.hasAttendance) {
        setShowWarning(true);
      } else {
        executeExclude();
      }
    }
  });

  const excludeMutation = useMutation({
    mutationFn: async () => {
      await apiRequest("POST", "/api/classes/exclude-sessions", {
        classId,
        fromSessionId,
        toSessionId,
        reason,
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [`/api/classes/${classId}`] });
      queryClient.invalidateQueries({ queryKey: [`/api/classes/${classId}/sessions`] });
      queryClient.invalidateQueries({ queryKey: [`/api/classes/${classId}/exclusions`] });
      queryClient.invalidateQueries({ queryKey: [`/api/classes/${classId}/active-students`] });
      queryClient.invalidateQueries({ queryKey: ["/api/classes", classId] });
      toast({
        title: "Thành công",
        description: "Đã loại trừ buổi học thành công",
      });
      onOpenChange(false);
      resetForm();
      setShowWarning(false);
    },
    onError: (error: Error) => {
      toast({
        title: "Lỗi",
        description: error.message || "Không thể loại trừ buổi học",
        variant: "destructive"
      });
    }
  });

  const resetForm = () => {
    setFromSessionId("");
    setToSessionId("");
    setReason("");
  };

  const executeExclude = () => excludeMutation.mutate();

  const fromIndex = classSessions.findIndex(s => s.id === fromSessionId);
  const toIndex = classSessions.findIndex(s => s.id === toSessionId);
  const sessionCount = fromIndex >= 0 && toIndex >= 0 ? Math.abs(toIndex - fromIndex) + 1 : 0;

  const { data: exclusionsData } = useQuery({
    queryKey: [`/api/classes/${classId}/exclusions`],
    queryFn: async () => {
      const res = await apiRequest("GET", `/api/classes/${classId}/exclusions`);
      return res.json();
    },
    enabled: isOpen
  });

  return (
    <>
      <Dialog open={isOpen && !showWarning} onOpenChange={onOpenChange}>
        <DialogContent className="max-w-3xl w-full">
          <DialogHeader className="pb-2">
            <DialogTitle className="text-base font-semibold">Loại trừ ngày học</DialogTitle>
            <DialogDescription className="text-xs">
              Các buổi phía sau khoảng loại trừ sẽ dồn lên thế chỗ. Hệ thống tự động tạo buổi bù ở cuối lịch.
            </DialogDescription>
          </DialogHeader>

          <div className="flex gap-5">
            {/* Left: form */}
            <div className="flex-1 space-y-3 min-w-0">
              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-1">
                  <Label className="text-xs">Từ buổi</Label>
                  <Select value={fromSessionId} onValueChange={setFromSessionId}>
                    <SelectTrigger data-testid="select-from-session" className="h-8 text-xs">
                      <SelectValue placeholder="Chọn buổi" />
                    </SelectTrigger>
                    <SelectContent>
                      {classSessions.map((s, idx) => (
                        <SelectItem key={s.id} value={s.id} className="text-xs">
                          Buổi {String(idx + 1).padStart(2, '0')}: {format(new Date(s.sessionDate), "EEE d/M/yy HH:mm", { locale: vi })}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-1">
                  <Label className="text-xs">Đến buổi</Label>
                  <Select value={toSessionId} onValueChange={setToSessionId}>
                    <SelectTrigger data-testid="select-to-session" className="h-8 text-xs">
                      <SelectValue placeholder="Chọn buổi" />
                    </SelectTrigger>
                    <SelectContent>
                      {classSessions.map((s, idx) => (
                        <SelectItem key={s.id} value={s.id} className="text-xs">
                          Buổi {String(idx + 1).padStart(2, '0')}: {format(new Date(s.sessionDate), "EEE d/M/yy HH:mm", { locale: vi })}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>

              {sessionCount > 0 && (
                <div className="px-3 py-2 bg-blue-50 border border-blue-200 rounded text-xs text-blue-900">
                  <strong>Loại trừ {sessionCount} buổi</strong>
                  {" — "}hệ thống sẽ tạo thêm {sessionCount} buổi bù vào cuối lịch theo chu kỳ hiện tại.
                </div>
              )}

              <div className="space-y-1">
                <Label className="text-xs">Lý do (không bắt buộc)</Label>
                <Textarea
                  data-testid="textarea-reason"
                  placeholder="Ví dụ: Nghỉ lễ, Giáo viên bận, Trung tâm nghỉ..."
                  value={reason}
                  onChange={(e) => setReason(e.target.value)}
                  className="h-20 text-xs resize-none"
                />
              </div>
            </div>

            {/* Right: history */}
            <div className="w-56 border-l pl-4 shrink-0">
              <p className="text-xs font-semibold flex items-center gap-1.5 mb-2 text-muted-foreground uppercase tracking-wide">
                <Clock className="h-3.5 w-3.5" />
                Lịch sử loại trừ
              </p>
              <ScrollArea className="h-52">
                {exclusionsData && exclusionsData.length > 0 ? (
                  <div className="space-y-2 pr-2">
                    {exclusionsData.map((exclusion: any) => (
                      <div key={exclusion.id} className="p-2 bg-muted/40 rounded border text-[11px] space-y-0.5">
                        <div className="font-medium text-foreground">
                          Buổi {String(exclusion.fromSessionOrder).padStart(2, '0')}
                          {exclusion.fromSessionOrder !== exclusion.toSessionOrder &&
                            ` — ${String(exclusion.toSessionOrder).padStart(2, '0')}`}
                        </div>
                        <div className="text-muted-foreground">
                          {format(new Date(exclusion.fromSessionDate), "EEE d/M/yy", { locale: vi })}
                          {exclusion.fromSessionDate !== exclusion.toSessionDate && (
                            <> — {format(new Date(exclusion.toSessionDate), "EEE d/M/yy", { locale: vi })}</>
                          )}
                        </div>
                        {exclusion.reason && (
                          <div className="text-muted-foreground italic truncate" title={exclusion.reason}>
                            {exclusion.reason}
                          </div>
                        )}
                        <div className="text-muted-foreground/60">
                          {format(new Date(exclusion.createdAt), "dd/MM/yy HH:mm", { locale: vi })}
                        </div>
                      </div>
                    ))}
                  </div>
                ) : (
                  <p className="text-[11px] text-muted-foreground text-center py-6">Chưa có lịch sử</p>
                )}
              </ScrollArea>
            </div>
          </div>

          <DialogFooter className="pt-2">
            <Button variant="outline" size="sm" onClick={() => onOpenChange(false)} data-testid="button-cancel">
              Hủy
            </Button>
            <Button
              size="sm"
              data-testid="button-exclude"
              disabled={!fromSessionId || !toSessionId || checkAttendanceMutation.isPending || excludeMutation.isPending}
              onClick={() => checkAttendanceMutation.mutate()}
            >
              {checkAttendanceMutation.isPending || excludeMutation.isPending ? "Đang xử lý..." : "Loại trừ"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Warning dialog */}
      <Dialog open={showWarning} onOpenChange={setShowWarning}>
        <DialogContent className="sm:max-w-sm">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2 text-destructive text-sm">
              <AlertCircle className="h-4 w-4" />
              Cảnh báo
            </DialogTitle>
          </DialogHeader>
          <p className="text-sm">
            Có {sessionCount} buổi trong khoảng đã chọn có học viên điểm danh. Bạn có chắc muốn loại trừ?
          </p>
          <DialogFooter>
            <Button variant="outline" size="sm" onClick={() => setShowWarning(false)} data-testid="button-warning-cancel">
              Hủy
            </Button>
            <Button
              size="sm"
              variant="destructive"
              data-testid="button-warning-continue"
              onClick={executeExclude}
              disabled={excludeMutation.isPending}
            >
              {excludeMutation.isPending ? "Đang xử lý..." : "Tiếp tục"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </>
  );
}
