import { useState, useEffect } from "react";
import { Eye, Loader2, ExternalLink, LogOut } from "lucide-react";
import { MyCalendarSessionLight, MyCalendarSession, SessionContentItem, TeacherReview, OnlineRuleConfig } from "@/types/my-calendar";
import { FeedbackModal } from "./FeedbackModal";
import { ContentViewDialog, ExamViewerFromId } from "@/components/education/SessionContentDialog";
import { useStudentSessionDetail } from "@/hooks/use-student-session-detail";
import { cn } from "@/lib/utils";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";

const ATTENDANCE_LABELS: Record<string, { label: string; color: string }> = {
  pending: { label: "Chưa điểm danh", color: "text-muted-foreground" },
  present: { label: "Có học", color: "text-green-600 font-semibold" },
  absent: { label: "Nghỉ học", color: "text-red-500 font-semibold" },
  makeup_wait: { label: "Nghỉ chờ bù", color: "text-orange-500 font-semibold" },
  makeup_done: { label: "Đã học bù", color: "text-blue-600 font-semibold" },
  paused: { label: "Bảo lưu", color: "text-yellow-600 font-semibold" },
};

const CONTENT_TYPE_LABELS: Record<string, string> = {
  lesson: "Bài học",
  "Bài học": "Bài học",
  homework: "BTVN",
  "Bài tập về nhà": "BTVN",
  curriculum: "Giáo trình",
  "Giáo trình": "Giáo trình",
  test: "Kiểm tra",
  "Bài kiểm tra": "Kiểm tra",
};

function getOnlinePlatformName(url: string): string {
  try {
    const hostname = new URL(url).hostname.toLowerCase();
    if (hostname.includes("meet.google")) return "Google Meet";
    if (hostname.includes("zoom.us") || hostname.includes("zoom.com")) return "Zoom";
    if (hostname.includes("teams.microsoft") || hostname.includes("teams.live")) return "Microsoft Teams";
    if (hostname.includes("webex")) return "Cisco Webex";
    if (hostname.includes("whereby")) return "Whereby";
    if (hostname.includes("jitsi")) return "Jitsi Meet";
    if (hostname.includes("skype")) return "Skype";
    const parts = hostname.replace(/^www\./, "").split(".");
    return parts[0].charAt(0).toUpperCase() + parts[0].slice(1);
  } catch {
    return "Link học online";
  }
}

function computeOnlineWindowState(
  sessionDate: string,
  startTime: string,
  endTime: string,
  rule: OnlineRuleConfig | null | undefined
): { canJoin: boolean; canEnd: boolean } {
  if (!rule) return { canJoin: true, canEnd: true };

  const [startH, startM] = startTime.split(":").map(Number);
  const [endH, endM] = endTime.split(":").map(Number);

  const base = new Date(sessionDate + "T00:00:00");

  const sessionStart = new Date(base);
  sessionStart.setHours(startH, startM, 0, 0);

  const sessionEnd = new Date(base);
  sessionEnd.setHours(endH, endM, 0, 0);

  const now = new Date();

  const joinFrom = new Date(sessionStart.getTime() - rule.earlyEntryMinutes * 60_000);
  const joinUntil = new Date(sessionStart.getTime() + rule.lateEntryMinutes * 60_000);
  const endFrom = new Date(sessionEnd.getTime() - rule.earlyEndMinutes * 60_000);

  const canJoin = now >= joinFrom && now <= joinUntil;
  const canEnd = now >= endFrom;

  return { canJoin, canEnd };
}

interface ContentRowProps {
  label: string;
  items: SessionContentItem[];
  onViewItem: (item: SessionContentItem) => void;
}

function ContentRow({ label, items, onViewItem }: ContentRowProps) {
  if (items.length === 0) return null;
  return (
    <div className="flex gap-1.5 text-sm flex-wrap">
      <span className="text-muted-foreground shrink-0">{label}:</span>
      <span className="flex flex-wrap gap-x-2">
        {items.map((item, idx) => (
          <button
            key={item.id}
            className="text-primary font-medium hover:underline text-left"
            onClick={() => onViewItem(item)}
            data-testid={`btn-view-content-${item.id}`}
          >
            {item.title}{idx < items.length - 1 ? " |" : ""}
          </button>
        ))}
      </span>
    </div>
  );
}

interface OnlineLinkButtonProps {
  classSessionId: string;
  studentId?: string | null;
  onlineLink: string;
  sessionDate: string;
  startTime: string;
  endTime: string;
  onlineRule?: OnlineRuleConfig | null;
  onlineClickedAt?: string | null;
  onlineEndedAt?: string | null;
  onRecorded: (clickedAt: string) => void;
}

function OnlineLinkButton({
  classSessionId,
  studentId,
  onlineLink,
  sessionDate,
  startTime,
  endTime,
  onlineRule,
  onlineClickedAt,
  onlineEndedAt,
  onRecorded,
}: OnlineLinkButtonProps) {
  const platformName = getOnlinePlatformName(onlineLink);
  const [localClickedAt, setLocalClickedAt] = useState<string | null>(onlineClickedAt ?? null);
  const [localEndedAt, setLocalEndedAt] = useState<string | null>(onlineEndedAt ?? null);
  const [, setTick] = useState(0);

  // Re-check time window every 30 seconds
  useEffect(() => {
    const id = setInterval(() => setTick((t) => t + 1), 30_000);
    return () => clearInterval(id);
  }, []);

  useEffect(() => {
    if (onlineClickedAt && !localClickedAt) setLocalClickedAt(onlineClickedAt);
  }, [onlineClickedAt]);

  useEffect(() => {
    if (onlineEndedAt && !localEndedAt) setLocalEndedAt(onlineEndedAt);
  }, [onlineEndedAt]);

  const queryClient = useQueryClient();

  const { canJoin, canEnd } = computeOnlineWindowState(sessionDate, startTime, endTime, onlineRule);

  const recordMutation = useMutation({
    mutationFn: async () => {
      const url = studentId
        ? `/api/my-space/calendar/student/session/${classSessionId}/online-click?studentId=${studentId}`
        : `/api/my-space/calendar/student/session/${classSessionId}/online-click`;
      const res = await apiRequest("POST", url);
      return res.json();
    },
    onSuccess: (data) => {
      if (data?.onlineClickedAt) {
        setLocalClickedAt(data.onlineClickedAt);
        onRecorded(data.onlineClickedAt);
      }
    },
  });

  const endMutation = useMutation({
    mutationFn: async () => {
      const url = studentId
        ? `/api/my-space/calendar/student/session/${classSessionId}/online-end?studentId=${studentId}`
        : `/api/my-space/calendar/student/session/${classSessionId}/online-end`;
      const res = await apiRequest("POST", url);
      return res.json();
    },
    onSuccess: (data) => {
      const endedAt = data?.onlineEndedAt ?? new Date().toISOString();
      setLocalEndedAt(endedAt);
      queryClient.invalidateQueries({ queryKey: ["/api/my-space/calendar/student/session", classSessionId] });
    },
  });

  const handleClick = () => {
    if (!localEndedAt) {
      recordMutation.mutate();
    }
    window.open(onlineLink, "_blank", "noopener,noreferrer");
  };

  const handleEnd = () => {
    const now = new Date().toISOString();
    setLocalEndedAt(now);
    endMutation.mutate();
  };

  return (
    <div className="flex flex-col items-start gap-1.5">
      <div className="flex items-center gap-2 flex-wrap">
        <button
          onClick={handleClick}
          disabled={!canJoin}
          data-testid={`btn-online-link-${classSessionId}`}
          className={cn(
            "inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold text-white transition-colors",
            canJoin
              ? "bg-purple-600 hover:bg-purple-700 active:bg-purple-800"
              : "bg-purple-300 cursor-not-allowed opacity-60"
          )}
        >
          <ExternalLink className="h-3.5 w-3.5" />
          {platformName}
        </button>
        {localClickedAt && !localEndedAt && (
          <button
            onClick={handleEnd}
            disabled={endMutation.isPending || !canEnd}
            data-testid={`btn-online-end-${classSessionId}`}
            className={cn(
              "inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold text-white transition-colors",
              canEnd
                ? "bg-gray-500 hover:bg-gray-600 active:bg-gray-700"
                : "bg-gray-300 cursor-not-allowed opacity-60",
              endMutation.isPending && "opacity-60"
            )}
          >
            {endMutation.isPending ? (
              <Loader2 className="h-3.5 w-3.5 animate-spin" />
            ) : (
              <LogOut className="h-3.5 w-3.5" />
            )}
            Kết thúc học online
          </button>
        )}
      </div>
      {!canJoin && !localClickedAt && onlineRule && (
        <span className="text-[11px] text-muted-foreground">
          Nút sẽ mở lúc{" "}
          {(() => {
            const [h, m] = startTime.split(":").map(Number);
            const t = new Date(sessionDate + "T00:00:00");
            t.setHours(h, m - onlineRule.earlyEntryMinutes, 0, 0);
            return t.toLocaleTimeString("vi-VN", { hour: "2-digit", minute: "2-digit" });
          })()}
        </span>
      )}
      {localClickedAt && (
        <span className="text-[11px] text-orange-500 font-medium">
          Đã vào lúc {new Date(localClickedAt).toLocaleTimeString("vi-VN", { hour: "2-digit", minute: "2-digit", second: "2-digit" })}
          {localEndedAt && (
            <> · Kết thúc lúc {new Date(localEndedAt).toLocaleTimeString("vi-VN", { hour: "2-digit", minute: "2-digit", second: "2-digit" })}</>
          )}
        </span>
      )}
    </div>
  );
}

interface SessionCardDetailProps {
  session: MyCalendarSession;
  sessionDate: string;
  onlineRule?: OnlineRuleConfig | null;
}

function SessionCardDetail({ session, sessionDate, onlineRule }: SessionCardDetailProps) {
  const queryClient = useQueryClient();
  const [showFeedback, setShowFeedback] = useState(false);
  const [viewingContentId, setViewingContentId] = useState<string | null>(null);
  const [viewingFallbackContent, setViewingFallbackContent] = useState<{ title: string; type: string; content?: string | null } | null>(null);
  const [viewingExamId, setViewingExamId] = useState<string | null>(null);

  const handleViewItem = (item: SessionContentItem) => {
    if (item.type === "Bài kiểm tra" || item.type === "test") {
      if (item.resourceUrl) {
        setViewingExamId(item.resourceUrl);
        return;
      }
    }
    if (item.resourceUrl) {
      setViewingContentId(item.resourceUrl);
      setViewingFallbackContent(null);
    } else {
      setViewingContentId(null);
      setViewingFallbackContent({ title: item.title, type: item.type, content: item.description });
    }
  };

  const attendance = session.attendanceStatus
    ? ATTENDANCE_LABELS[session.attendanceStatus] ?? { label: session.attendanceStatus, color: "text-muted-foreground" }
    : null;

  const hasOnlineLink = !!session.onlineLink;
  const isOnline = session.learningFormat === "online" || hasOnlineLink;

  const generalLessons = session.generalContents.filter((c) => c.type === "lesson" || c.type === "Bài học");
  const generalHomework = session.generalContents.filter((c) => c.type === "homework" || c.type === "Bài tập về nhà");
  const generalOther = session.generalContents.filter((c) => !["lesson", "Bài học", "homework", "Bài tập về nhà"].includes(c.type));

  const personalLessons = session.personalContents.filter((c) => c.type === "lesson" || c.type === "Bài học");
  const personalHomework = session.personalContents.filter((c) => c.type === "homework" || c.type === "Bài tập về nhà");
  const personalOther = session.personalContents.filter((c) => !["lesson", "Bài học", "homework", "Bài tập về nhà"].includes(c.type));

  const safeReviewData: TeacherReview[] = Array.isArray(session.reviewData) ? session.reviewData : [];
  const hasPersonalContent = session.personalContents.length > 0;
  const hasGeneralContent = session.generalContents.length > 0;
  const hasReview = session.reviewPublished && safeReviewData.length > 0;

  const displayDate = new Date(sessionDate + "T00:00:00").toLocaleDateString("vi-VN", {
    weekday: "long",
    day: "2-digit",
    month: "2-digit",
  });

  const handleOnlineRecorded = (_clickedAt: string) => {
    queryClient.invalidateQueries({ queryKey: ["/api/my-space/calendar/student/session", session.classSessionId] });
  };

  return (
    <>
      <div className="bg-card rounded-2xl border border-border p-5 space-y-3 shadow-sm hover:shadow-md transition-shadow">
        {/* Header row */}
        <div className="flex items-start justify-between gap-4">
          <div className="space-y-1 min-w-0">
            <p className="text-sm text-muted-foreground">
              Thời gian: <span className="font-bold text-foreground">{session.startTime} - {session.endTime}</span>
            </p>
            <p className="font-bold text-foreground text-base">Lớp: {session.classCode}</p>
            <p className="text-sm text-muted-foreground">
              GV: <span className="font-medium text-foreground">{session.teacherNames.join(", ") || "—"}</span>
            </p>
            {session.studentName && (
              <p className="text-sm text-muted-foreground">
                HV:{" "}
                <span className="font-medium text-foreground">
                  {session.studentName}
                  {session.studentCode && ` (${session.studentCode})`}
                </span>
                {session.enrolledCount !== undefined && (
                  <span className="ml-1.5 font-semibold text-orange-500">({session.enrolledCount})</span>
                )}
              </p>
            )}
          </div>
          <div className="flex flex-col items-end gap-1 shrink-0">
            {attendance && (
              <span className={cn("text-sm", attendance.color)}>
                {attendance.label}
              </span>
            )}
            <span className={cn(
              "text-sm font-medium",
              isOnline ? "text-blue-500" : "text-muted-foreground"
            )}>
              {isOnline ? "Online" : "Offline"}
            </span>
          </div>
        </div>

        {/* Online link button */}
        {hasOnlineLink && (
          <div className="border-t border-border/50 pt-3">
            <OnlineLinkButton
              classSessionId={session.classSessionId}
              studentId={session.studentId ?? null}
              onlineLink={session.onlineLink!}
              sessionDate={sessionDate}
              startTime={session.startTime}
              endTime={session.endTime}
              onlineRule={onlineRule}
              onlineClickedAt={session.onlineClickedAt}
              onlineEndedAt={session.onlineEndedAt}
              onRecorded={handleOnlineRecorded}
            />
          </div>
        )}

        {/* General content */}
        {hasGeneralContent && (
          <div className="space-y-1.5 border-t border-border/50 pt-3">
            <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wide">Nội dung chung</p>
            <ContentRow label="Bài học" items={generalLessons} onViewItem={handleViewItem} />
            <ContentRow label="BTVN" items={generalHomework} onViewItem={handleViewItem} />
            {generalOther.map((item) => (
              <ContentRow key={item.id} label={CONTENT_TYPE_LABELS[item.type] ?? item.type} items={[item]} onViewItem={handleViewItem} />
            ))}
          </div>
        )}

        {/* Personal content */}
        {hasPersonalContent && (
          <div className="space-y-1.5 border-t border-border/50 pt-3">
            <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wide">Nội dung cá nhân</p>
            <ContentRow label="Bài học" items={personalLessons} onViewItem={handleViewItem} />
            <ContentRow label="BTVN" items={personalHomework} onViewItem={handleViewItem} />
            {personalOther.map((item) => (
              <ContentRow key={item.id} label={CONTENT_TYPE_LABELS[item.type] ?? item.type} items={[item]} onViewItem={handleViewItem} />
            ))}
          </div>
        )}

        {/* Review row */}
        <div className="flex items-center gap-2 border-t border-border/50 pt-3">
          <span className="text-sm text-muted-foreground">Nhận xét:</span>
          {hasReview ? (
            <button
              onClick={() => setShowFeedback(true)}
              className="flex items-center gap-1.5 text-sm text-primary hover:text-primary/80 transition-colors"
              data-testid="btn-view-feedback"
            >
              <Eye className="h-4 w-4" />
              <span>Xem nhận xét</span>
            </button>
          ) : (
            <span className="text-sm text-muted-foreground italic">Chưa có nhận xét</span>
          )}
        </div>
      </div>

      <FeedbackModal
        open={showFeedback}
        onClose={() => setShowFeedback(false)}
        reviewData={safeReviewData}
        className={session.classCode}
        sessionDate={displayDate}
      />

      <ContentViewDialog
        isOpen={!!viewingContentId || !!viewingFallbackContent}
        onOpenChange={(open) => { if (!open) { setViewingContentId(null); setViewingFallbackContent(null); } }}
        contentId={viewingContentId}
        fallbackContent={viewingFallbackContent}
      />
      <ExamViewerFromId
        examId={viewingExamId || ""}
        open={!!viewingExamId}
        onClose={() => setViewingExamId(null)}
      />
    </>
  );
}

interface SessionCardProps {
  session: MyCalendarSessionLight;
  sessionDate: string;
  onlineRule?: OnlineRuleConfig | null;
}

export function SessionCard({ session, sessionDate, onlineRule }: SessionCardProps) {
  const { data: detail, isLoading, isError } = useStudentSessionDetail(session.classSessionId, session.studentId);

  const attendance = session.attendanceStatus
    ? ATTENDANCE_LABELS[session.attendanceStatus] ?? { label: session.attendanceStatus, color: "text-muted-foreground" }
    : null;

  const isOnline = session.learningFormat === "online" || !!session.onlineLink;

  if (isLoading) {
    return (
      <div className="bg-card rounded-2xl border border-border p-5 shadow-sm">
        <div className="flex items-start justify-between gap-4">
          <div className="space-y-1 min-w-0">
            <p className="text-sm text-muted-foreground">
              Thời gian: <span className="font-bold text-foreground">{session.startTime} - {session.endTime}</span>
            </p>
            <p className="font-bold text-foreground text-base">Lớp: {session.classCode}</p>
          </div>
          <div className="flex flex-col items-end gap-1 shrink-0">
            {attendance && (
              <span className={cn("text-sm", attendance.color)}>{attendance.label}</span>
            )}
            <span className={cn("text-sm font-medium", isOnline ? "text-blue-500" : "text-muted-foreground")}>
              {isOnline ? "Online" : "Offline"}
            </span>
          </div>
        </div>
        <div className="flex items-center gap-2 mt-3 pt-3 border-t border-border/50 text-muted-foreground text-sm">
          <Loader2 className="h-3.5 w-3.5 animate-spin" />
          <span>Đang tải nội dung...</span>
        </div>
      </div>
    );
  }

  if (isError || !detail) {
    return (
      <div className="bg-card rounded-2xl border border-border p-5 shadow-sm">
        <div className="flex items-start justify-between gap-4">
          <div className="space-y-1 min-w-0">
            <p className="text-sm text-muted-foreground">
              Thời gian: <span className="font-bold text-foreground">{session.startTime} - {session.endTime}</span>
            </p>
            <p className="font-bold text-foreground text-base">Lớp: {session.classCode}</p>
          </div>
          <div className="flex flex-col items-end gap-1 shrink-0">
            {attendance && (
              <span className={cn("text-sm shrink-0", attendance.color)}>{attendance.label}</span>
            )}
            <span className={cn("text-sm font-medium", isOnline ? "text-blue-500" : "text-muted-foreground")}>
              {isOnline ? "Online" : "Offline"}
            </span>
          </div>
        </div>
        <p className="text-xs text-red-500 mt-2">Không thể tải chi tiết buổi học</p>
      </div>
    );
  }

  return <SessionCardDetail session={detail} sessionDate={sessionDate} onlineRule={onlineRule} />;
}
