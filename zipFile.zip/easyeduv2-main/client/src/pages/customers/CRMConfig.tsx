import { useState, useEffect } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { DashboardLayout } from "@/components/layout/DashboardLayout";
import { Tabs, TabsContent } from "@/components/ui/tabs";
import { cn } from "@/lib/utils";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogTrigger } from "@/components/ui/dialog";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { insertCrmRelationshipSchema, insertCrmRejectReasonSchema, insertCrmCustomerSourceSchema, insertCrmCustomFieldSchema, type CrmRelationship, type CrmRejectReason, type CrmCustomerSource } from "@shared/schema";
import { Plus, Pencil, Trash2, Settings2 } from "lucide-react";
import { Checkbox } from "@/components/ui/checkbox";
import { Select, SelectTrigger, SelectValue, SelectContent, SelectItem } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { useToast } from "@/hooks/use-toast";
import { useSidebarVisibility } from "@/hooks/use-sidebar-visibility";
import { useMyPermissions } from "@/hooks/use-my-permissions";
import { useCrmRequiredFields, useCrmCustomFields, type CrmRequiredField, type CrmCustomField } from "@/hooks/use-crm-config";
import { CRM_CONFIGURABLE_FIELDS, CRM_FIELD_GROUP_LABELS, makeCustomFieldKey, type CrmConfigurableField } from "@/lib/crm-customer-fields";
import { api } from "@shared/routes";

const CRM_CONFIG_HREF = "/customers/crm-config";
const ALL_TABS = [
  { value: "relationships", label: "Mối quan hệ" },
  { value: "reject-reasons", label: "Lý do từ chối" },
  { value: "sources", label: "Nguồn khách hàng" },
  { value: "additional-info", label: "Thông tin bổ sung" },
  { value: "required-info", label: "Thông tin bắt buộc" },
];

interface TabPerms {
  canCreate: boolean;
  canEdit: boolean;
  canDelete: boolean;
}

function useTabPerms(tabValue: string): TabPerms {
  const { data: myPerms } = useMyPermissions();
  if (myPerms?.isSuperAdmin) return { canCreate: true, canEdit: true, canDelete: true };
  const resource = `${CRM_CONFIG_HREF}#${tabValue}`;
  const perm = myPerms?.permissions?.[resource];
  return {
    canCreate: perm?.canCreate ?? false,
    canEdit: perm?.canEdit ?? false,
    canDelete: perm?.canDelete ?? false,
  };
}

export function CRMConfig() {
  const { toast } = useToast();
  const { isSubTabVisible } = useSidebarVisibility();
  const { data: myPerms } = useMyPermissions();

  const visibleTabs = ALL_TABS.filter(t => {
    if (!isSubTabVisible(CRM_CONFIG_HREF, t.value)) return false;
    if (myPerms?.isSuperAdmin) return true;
    const resource = `${CRM_CONFIG_HREF}#${t.value}`;
    const perm = myPerms?.permissions?.[resource];
    return perm?.canView || perm?.canViewAll || perm?.canCreate || perm?.canEdit || perm?.canDelete;
  });
  const [activeTab, setActiveTab] = useState(() => visibleTabs[0]?.value || "relationships");

  useEffect(() => {
    if (!visibleTabs.find(t => t.value === activeTab) && visibleTabs.length > 0) {
      setActiveTab(visibleTabs[0].value);
    }
  }, [visibleTabs.map(t => t.value).join(",")]);

  if (visibleTabs.length === 0) {
    return (
      <DashboardLayout>
        <div className="space-y-6">
          <div>
            <h1 className="text-3xl font-display font-bold text-foreground flex items-center gap-2">
              <Settings2 className="h-8 w-8 text-primary" />
              Cấu hình CRM
            </h1>
          </div>
          <p className="text-muted-foreground">Tất cả các tab đã bị ẩn. Vui lòng bật lại trong Quản lý module.</p>
        </div>
      </DashboardLayout>
    );
  }

  return (
    <DashboardLayout>
      <div className="space-y-6">
        <div>
          <h1 className="text-3xl font-display font-bold text-foreground flex items-center gap-2">
            <Settings2 className="h-8 w-8 text-primary" />
            Cấu hình CRM
          </h1>
          <p className="text-muted-foreground">Quản lý các danh mục cấu hình cho module khách hàng</p>
        </div>

        <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
          <div className="flex flex-wrap gap-2 mb-4">
            {visibleTabs.map(t => (
              <button
                key={t.value}
                onClick={() => setActiveTab(t.value)}
                className={cn("px-3 py-1 rounded-md border text-xs font-medium transition-all", activeTab === t.value ? "bg-primary border-primary text-primary-foreground" : "bg-background border-border text-foreground hover:bg-muted/50")}
              >{t.label}</button>
            ))}
          </div>
          
          {isSubTabVisible(CRM_CONFIG_HREF, "relationships") && (
            <TabsContent value="relationships">
              <RelationshipTab />
            </TabsContent>
          )}
          
          {isSubTabVisible(CRM_CONFIG_HREF, "reject-reasons") && (
            <TabsContent value="reject-reasons">
              <RejectReasonTab />
            </TabsContent>
          )}
          
          {isSubTabVisible(CRM_CONFIG_HREF, "sources") && (
            <TabsContent value="sources">
              <CustomerSourceTab />
            </TabsContent>
          )}

          {isSubTabVisible(CRM_CONFIG_HREF, "additional-info") && (
            <TabsContent value="additional-info">
              <AdditionalInfoTab />
            </TabsContent>
          )}

          {isSubTabVisible(CRM_CONFIG_HREF, "required-info") && (
            <TabsContent value="required-info">
              <RequiredInfoTab />
            </TabsContent>
          )}
        </Tabs>
      </div>
    </DashboardLayout>
  );
}

function RelationshipTab() {
  const { toast } = useToast();
  const { canCreate, canEdit, canDelete } = useTabPerms("relationships");
  const [editing, setEditing] = useState<CrmRelationship | null>(null);
  const [open, setOpen] = useState(false);

  const { data: list, isLoading } = useQuery<CrmRelationship[]>({
    queryKey: ["/api/crm/relationships"],
  });

  const form = useForm({
    resolver: zodResolver(insertCrmRelationshipSchema),
    defaultValues: { name: "", color: "#3b82f6", position: "" },
  });

  const createMutation = useMutation({
    mutationFn: async (data: any) => {
      if (editing) {
        return apiRequest("PUT", `/api/crm/relationships/${editing.id}`, data);
      }
      return apiRequest("POST", "/api/crm/relationships", data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/crm/relationships"] });
      setOpen(false);
      setEditing(null);
      form.reset();
      toast({ title: "Thành công", description: "Đã lưu thông tin mối quan hệ" });
    }
  });

  const deleteMutation = useMutation({
    mutationFn: async (id: string) => apiRequest("DELETE", `/api/crm/relationships/${id}`),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/crm/relationships"] });
      toast({ title: "Đã xoá", description: "Đã xoá mối quan hệ" });
    }
  });

  const handleEdit = (item: CrmRelationship) => {
    setEditing(item);
    form.reset({ name: item.name, color: item.color, position: item.position || "" });
    setOpen(true);
  };

  return (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-4">
        <div>
          <CardTitle>Mối quan hệ</CardTitle>
          <CardDescription>Cấu hình các mức độ mối quan hệ với khách hàng</CardDescription>
        </div>
        {canCreate && (
          <Dialog open={open} onOpenChange={(val) => { setOpen(val); if (!val) setEditing(null); }}>
            <DialogTrigger asChild>
              <Button onClick={() => { setEditing(null); form.reset({ name: "", color: "#3b82f6", position: "" }); }}>
                <Plus className="h-4 w-4 mr-2" /> Thêm mới
              </Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader><DialogTitle>{editing ? "Sửa mối quan hệ" : "Thêm mới mối quan hệ"}</DialogTitle></DialogHeader>
              <Form {...form}>
                <form onSubmit={form.handleSubmit((data) => createMutation.mutate(data))} className="space-y-4">
                  <FormField control={form.control} name="name" render={({ field }) => (
                    <FormItem><FormLabel>Tên mối quan hệ</FormLabel><FormControl><Input {...field} /></FormControl><FormMessage /></FormItem>
                  )} />
                  <FormField control={form.control} name="color" render={({ field }) => (
                    <FormItem><FormLabel>Màu sắc</FormLabel><FormControl><Input type="color" {...field} /></FormControl><FormMessage /></FormItem>
                  )} />
                  <FormField control={form.control} name="position" render={({ field }) => (
                    <FormItem><FormLabel>Vị trí</FormLabel><FormControl><Input {...field} /></FormControl><FormMessage /></FormItem>
                  )} />
                  <DialogFooter><Button type="submit" disabled={createMutation.isPending}>{editing ? "Cập nhật" : "Thêm mới"}</Button></DialogFooter>
                </form>
              </Form>
            </DialogContent>
          </Dialog>
        )}
      </CardHeader>
      <CardContent>
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Tên</TableHead>
              <TableHead>Màu sắc</TableHead>
              <TableHead>Vị trí</TableHead>
              {(canEdit || canDelete) && <TableHead className="text-right">Thao tác</TableHead>}
            </TableRow>
          </TableHeader>
          <TableBody>
            {list?.map((item) => (
              <TableRow key={item.id}>
                <TableCell className="font-medium">{item.name}</TableCell>
                <TableCell><div className="flex items-center gap-2"><div className="w-4 h-4 rounded" style={{ backgroundColor: item.color }} /> {item.color}</div></TableCell>
                <TableCell>{item.position}</TableCell>
                {(canEdit || canDelete) && (
                  <TableCell className="text-right space-x-2">
                    {canEdit && (
                      <Button variant="ghost" size="icon" onClick={() => handleEdit(item)}><Pencil className="h-4 w-4" /></Button>
                    )}
                    {canDelete && (
                      <Button variant="ghost" size="icon" className="text-destructive" onClick={() => deleteMutation.mutate(item.id)}><Trash2 className="h-4 w-4" /></Button>
                    )}
                  </TableCell>
                )}
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </CardContent>
    </Card>
  );
}

function RejectReasonTab() {
  const { toast } = useToast();
  const { canCreate, canEdit, canDelete } = useTabPerms("reject-reasons");
  const [editing, setEditing] = useState<CrmRejectReason | null>(null);
  const [open, setOpen] = useState(false);

  const { data: list } = useQuery<CrmRejectReason[]>({ queryKey: ["/api/crm/reject-reasons"] });

  const form = useForm({
    resolver: zodResolver(insertCrmRejectReasonSchema),
    defaultValues: { reason: "" },
  });

  const createMutation = useMutation({
    mutationFn: async (data: any) => {
      if (editing) return apiRequest("PUT", `/api/crm/reject-reasons/${editing.id}`, data);
      return apiRequest("POST", "/api/crm/reject-reasons", data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/crm/reject-reasons"] });
      setOpen(false); setEditing(null); form.reset();
      toast({ title: "Thành công", description: "Đã lưu lý do từ chối" });
    }
  });

  const deleteMutation = useMutation({
    mutationFn: async (id: string) => apiRequest("DELETE", `/api/crm/reject-reasons/${id}`),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/crm/reject-reasons"] });
      toast({ title: "Đã xoá", description: "Đã xoá lý do từ chối" });
    }
  });

  const handleEdit = (item: CrmRejectReason) => {
    setEditing(item);
    form.reset({ reason: item.reason });
    setOpen(true);
  };

  return (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-4">
        <div><CardTitle>Lý do từ chối</CardTitle><CardDescription>Quản lý các lý do khách hàng từ chối dịch vụ</CardDescription></div>
        {canCreate && (
          <Dialog open={open} onOpenChange={(val) => { setOpen(val); if (!val) setEditing(null); }}>
            <DialogTrigger asChild><Button onClick={() => { setEditing(null); form.reset({ reason: "" }); }}><Plus className="h-4 w-4 mr-2" /> Thêm mới</Button></DialogTrigger>
            <DialogContent>
              <DialogHeader><DialogTitle>{editing ? "Sửa lý do" : "Thêm lý do mới"}</DialogTitle></DialogHeader>
              <Form {...form}>
                <form onSubmit={form.handleSubmit((data) => createMutation.mutate(data))} className="space-y-4">
                  <FormField control={form.control} name="reason" render={({ field }) => (
                    <FormItem><FormLabel>Nội dung lý do</FormLabel><FormControl><Input {...field} /></FormControl><FormMessage /></FormItem>
                  )} />
                  <DialogFooter><Button type="submit" disabled={createMutation.isPending}>{editing ? "Cập nhật" : "Thêm mới"}</Button></DialogFooter>
                </form>
              </Form>
            </DialogContent>
          </Dialog>
        )}
      </CardHeader>
      <CardContent>
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Lý do</TableHead>
              {(canEdit || canDelete) && <TableHead className="text-right">Thao tác</TableHead>}
            </TableRow>
          </TableHeader>
          <TableBody>
            {list?.map((item) => (
              <TableRow key={item.id}>
                <TableCell>{item.reason}</TableCell>
                {(canEdit || canDelete) && (
                  <TableCell className="text-right space-x-2">
                    {canEdit && (
                      <Button variant="ghost" size="icon" onClick={() => handleEdit(item)}><Pencil className="h-4 w-4" /></Button>
                    )}
                    {canDelete && (
                      <Button variant="ghost" size="icon" className="text-destructive" onClick={() => deleteMutation.mutate(item.id)}><Trash2 className="h-4 w-4" /></Button>
                    )}
                  </TableCell>
                )}
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </CardContent>
    </Card>
  );
}

function CustomerSourceTab() {
  const { toast } = useToast();
  const { canCreate, canEdit, canDelete } = useTabPerms("sources");
  const [editing, setEditing] = useState<CrmCustomerSource | null>(null);
  const [open, setOpen] = useState(false);

  const { data: list } = useQuery<CrmCustomerSource[]>({ queryKey: ["/api/crm/customer-sources"] });

  const form = useForm({
    resolver: zodResolver(insertCrmCustomerSourceSchema),
    defaultValues: { name: "" },
  });

  const createMutation = useMutation({
    mutationFn: async (data: any) => {
      if (editing) return apiRequest("PUT", `/api/crm/customer-sources/${editing.id}`, data);
      return apiRequest("POST", "/api/crm/customer-sources", data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/crm/customer-sources"] });
      setOpen(false); setEditing(null); form.reset();
      toast({ title: "Thành công", description: "Đã lưu nguồn khách hàng" });
    }
  });

  const deleteMutation = useMutation({
    mutationFn: async (id: string) => apiRequest("DELETE", `/api/crm/customer-sources/${id}`),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/crm/customer-sources"] });
      toast({ title: "Đã xoá", description: "Đã xoá nguồn khách hàng" });
    }
  });

  const handleEdit = (item: CrmCustomerSource) => {
    setEditing(item);
    form.reset({ name: item.name });
    setOpen(true);
  };

  return (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-4">
        <div><CardTitle>Nguồn khách hàng</CardTitle><CardDescription>Quản lý các nguồn đến của khách hàng</CardDescription></div>
        {canCreate && (
          <Dialog open={open} onOpenChange={(val) => { setOpen(val); if (!val) setEditing(null); }}>
            <DialogTrigger asChild><Button onClick={() => { setEditing(null); form.reset({ name: "" }); }}><Plus className="h-4 w-4 mr-2" /> Thêm mới</Button></DialogTrigger>
            <DialogContent>
              <DialogHeader><DialogTitle>{editing ? "Sửa nguồn" : "Thêm nguồn mới"}</DialogTitle></DialogHeader>
              <Form {...form}>
                <form onSubmit={form.handleSubmit((data) => createMutation.mutate(data))} className="space-y-4">
                  <FormField control={form.control} name="name" render={({ field }) => (
                    <FormItem><FormLabel>Tên nguồn</FormLabel><FormControl><Input {...field} /></FormControl><FormMessage /></FormItem>
                  )} />
                  <DialogFooter><Button type="submit" disabled={createMutation.isPending}>{editing ? "Cập nhật" : "Thêm mới"}</Button></DialogFooter>
                </form>
              </Form>
            </DialogContent>
          </Dialog>
        )}
      </CardHeader>
      <CardContent>
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Nguồn</TableHead>
              {(canEdit || canDelete) && <TableHead className="text-right">Thao tác</TableHead>}
            </TableRow>
          </TableHeader>
          <TableBody>
            {list?.map((item) => (
              <TableRow key={item.id}>
                <TableCell>{item.name}</TableCell>
                {(canEdit || canDelete) && (
                  <TableCell className="text-right space-x-2">
                    {canEdit && (
                      <Button variant="ghost" size="icon" onClick={() => handleEdit(item)}><Pencil className="h-4 w-4" /></Button>
                    )}
                    {canDelete && (
                      <Button variant="ghost" size="icon" className="text-destructive" onClick={() => deleteMutation.mutate(item.id)}><Trash2 className="h-4 w-4" /></Button>
                    )}
                  </TableCell>
                )}
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </CardContent>
    </Card>
  );
}

const FIELD_TYPE_OPTIONS: { value: CrmCustomField["fieldType"]; label: string }[] = [
  { value: "text", label: "Văn bản ngắn" },
  { value: "textarea", label: "Văn bản dài" },
  { value: "number", label: "Số" },
  { value: "date", label: "Ngày" },
  { value: "select", label: "Chọn từ danh sách" },
];

function AdditionalInfoTab() {
  const { toast } = useToast();
  const { canCreate, canEdit, canDelete } = useTabPerms("additional-info");
  const [editing, setEditing] = useState<CrmCustomField | null>(null);
  const [open, setOpen] = useState(false);
  const [optionsText, setOptionsText] = useState("");

  const { data: list, isLoading } = useCrmCustomFields();

  const form = useForm<any>({
    resolver: zodResolver(insertCrmCustomFieldSchema) as any,
    defaultValues: { label: "", fieldType: "text", options: undefined, position: 0 },
  });

  const fieldType = form.watch("fieldType") as CrmCustomField["fieldType"];

  const saveMutation = useMutation({
    mutationFn: async (data: any) => {
      if (editing) {
        return apiRequest("PUT", `/api/crm/custom-fields/${editing.id}`, data);
      }
      return apiRequest("POST", "/api/crm/custom-fields", data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [api.crm.customFields.list.path] });
      setOpen(false); setEditing(null); form.reset(); setOptionsText("");
      toast({ title: "Thành công", description: "Đã lưu trường tùy chỉnh" });
    },
    onError: (err: any) => {
      toast({ title: "Lỗi", description: err?.message || "Không lưu được", variant: "destructive" });
    },
  });

  const deleteMutation = useMutation({
    mutationFn: async (id: string) => apiRequest("DELETE", `/api/crm/custom-fields/${id}`),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [api.crm.customFields.list.path] });
      queryClient.invalidateQueries({ queryKey: [api.crm.requiredFields.list.path] });
      queryClient.invalidateQueries({ queryKey: ["/api/students"] });
      toast({ title: "Đã xoá", description: "Đã xoá trường tùy chỉnh" });
    },
  });

  const openCreate = () => {
    setEditing(null);
    form.reset({ label: "", fieldType: "text", options: undefined, position: (list?.length ?? 0) });
    setOptionsText("");
    setOpen(true);
  };

  const openEdit = (item: CrmCustomField) => {
    setEditing(item);
    form.reset({
      label: item.label,
      fieldType: item.fieldType,
      options: item.options ?? undefined,
      position: item.position,
    });
    setOptionsText((item.options ?? []).join("\n"));
    setOpen(true);
  };

  const onSubmit = (data: any) => {
    const payload: any = {
      label: data.label?.trim(),
      fieldType: data.fieldType,
      position: Number(data.position) || 0,
    };
    if (data.fieldType === "select") {
      const opts = optionsText.split("\n").map(s => s.trim()).filter(Boolean);
      if (opts.length === 0) {
        toast({ title: "Lỗi", description: "Vui lòng nhập ít nhất một lựa chọn", variant: "destructive" });
        return;
      }
      payload.options = opts;
    } else {
      payload.options = null;
    }
    saveMutation.mutate(payload);
  };

  return (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-4">
        <div>
          <CardTitle>Thông tin bổ sung</CardTitle>
          <CardDescription>
            Tạo các trường thông tin tùy chỉnh để bổ sung vào hồ sơ Học viên / Phụ huynh.
          </CardDescription>
        </div>
        {canCreate && (
          <Dialog open={open} onOpenChange={(val) => { setOpen(val); if (!val) { setEditing(null); setOptionsText(""); } }}>
            <DialogTrigger asChild>
              <Button onClick={openCreate} data-testid="button-add-custom-field">
                <Plus className="h-4 w-4 mr-2" /> Thêm mới
              </Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>{editing ? "Sửa trường thông tin" : "Thêm trường thông tin"}</DialogTitle>
              </DialogHeader>
              <Form {...form}>
                <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
                  <FormField control={form.control} name="label" render={({ field }) => (
                    <FormItem>
                      <FormLabel>Tên trường <span className="text-destructive">*</span></FormLabel>
                      <FormControl><Input {...field} data-testid="input-custom-field-label" /></FormControl>
                      <FormMessage />
                    </FormItem>
                  )} />
                  <FormField control={form.control} name="fieldType" render={({ field }) => (
                    <FormItem>
                      <FormLabel>Loại dữ liệu</FormLabel>
                      <Select value={field.value} onValueChange={field.onChange}>
                        <FormControl>
                          <SelectTrigger data-testid="select-custom-field-type">
                            <SelectValue />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          {FIELD_TYPE_OPTIONS.map(o => (
                            <SelectItem key={o.value} value={o.value}>{o.label}</SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )} />
                  {fieldType === "select" && (
                    <FormItem>
                      <FormLabel>Danh sách lựa chọn (mỗi dòng 1 lựa chọn)</FormLabel>
                      <FormControl>
                        <Textarea
                          value={optionsText}
                          onChange={(e) => setOptionsText(e.target.value)}
                          rows={4}
                          placeholder={"Lựa chọn 1\nLựa chọn 2"}
                          data-testid="textarea-custom-field-options"
                        />
                      </FormControl>
                    </FormItem>
                  )}
                  <DialogFooter>
                    <Button type="submit" disabled={saveMutation.isPending} data-testid="button-save-custom-field">
                      {editing ? "Cập nhật" : "Thêm mới"}
                    </Button>
                  </DialogFooter>
                </form>
              </Form>
            </DialogContent>
          </Dialog>
        )}
      </CardHeader>
      <CardContent>
        {isLoading ? (
          <p className="text-sm text-muted-foreground">Đang tải...</p>
        ) : (
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Tên trường</TableHead>
                <TableHead>Loại dữ liệu</TableHead>
                {(canEdit || canDelete) && <TableHead className="text-right">Thao tác</TableHead>}
              </TableRow>
            </TableHeader>
            <TableBody>
              {(list ?? []).map((item) => (
                <TableRow key={item.id} data-testid={`row-custom-field-${item.id}`}>
                  <TableCell className="font-medium" data-testid={`text-custom-field-label-${item.id}`}>{item.label}</TableCell>
                  <TableCell>{FIELD_TYPE_OPTIONS.find(o => o.value === item.fieldType)?.label ?? item.fieldType}</TableCell>
                  {(canEdit || canDelete) && (
                    <TableCell className="text-right space-x-2">
                      {canEdit && (
                        <Button variant="ghost" size="icon" onClick={() => openEdit(item)} data-testid={`button-edit-custom-field-${item.id}`}>
                          <Pencil className="h-4 w-4" />
                        </Button>
                      )}
                      {canDelete && (
                        <Button
                          variant="ghost"
                          size="icon"
                          className="text-destructive"
                          onClick={() => {
                            if (confirm(`Xoá trường "${item.label}"? Dữ liệu đã nhập sẽ bị xoá theo.`)) {
                              deleteMutation.mutate(item.id);
                            }
                          }}
                          data-testid={`button-delete-custom-field-${item.id}`}
                        >
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      )}
                    </TableCell>
                  )}
                </TableRow>
              ))}
              {(!list || list.length === 0) && (
                <TableRow>
                  <TableCell colSpan={5} className="text-center text-sm text-muted-foreground py-8">
                    Chưa có trường tùy chỉnh nào. Bấm "Thêm mới" để tạo.
                  </TableCell>
                </TableRow>
              )}
            </TableBody>
          </Table>
        )}
      </CardContent>
    </Card>
  );
}

function RequiredInfoTab() {
  const { toast } = useToast();
  const { canEdit } = useTabPerms("required-info");
  const { data: list, isLoading } = useCrmRequiredFields();
  const { data: customFields } = useCrmCustomFields();

  const requiredMap = new Map<string, boolean>(
    (list ?? []).map((r: CrmRequiredField) => [r.fieldKey, r.isRequired]),
  );

  const upsertMutation = useMutation({
    mutationFn: async (vars: { fieldKey: string; isRequired: boolean }) => {
      return apiRequest("PUT", api.crm.requiredFields.upsert.path, vars);
    },
    onMutate: async (vars) => {
      await queryClient.cancelQueries({ queryKey: [api.crm.requiredFields.list.path] });
      const prev = queryClient.getQueryData<CrmRequiredField[]>([api.crm.requiredFields.list.path]);
      const next: CrmRequiredField[] = [...(prev ?? [])];
      const idx = next.findIndex(r => r.fieldKey === vars.fieldKey);
      if (idx >= 0) next[idx] = { ...next[idx], isRequired: vars.isRequired };
      else next.push({ fieldKey: vars.fieldKey, isRequired: vars.isRequired });
      queryClient.setQueryData([api.crm.requiredFields.list.path], next);
      return { prev };
    },
    onError: (_err, _vars, ctx) => {
      if (ctx?.prev) queryClient.setQueryData([api.crm.requiredFields.list.path], ctx.prev);
      toast({ title: "Lỗi", description: "Không lưu được cấu hình", variant: "destructive" });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [api.crm.requiredFields.list.path] });
    },
  });

  const customAsConfigurable: CrmConfigurableField[] = (customFields ?? []).map(c => ({
    key: makeCustomFieldKey(c.id),
    label: c.label,
    group: "additional",
  }));
  const allFields: CrmConfigurableField[] = [...CRM_CONFIGURABLE_FIELDS, ...customAsConfigurable];
  const groups = Array.from(new Set(allFields.map(f => f.group)));

  return (
    <Card>
      <CardHeader className="pb-4">
        <CardTitle>Thông tin bắt buộc</CardTitle>
        <CardDescription>
          Tích chọn các trường thông tin sẽ trở thành bắt buộc (có dấu *) khi thêm/sửa Học viên hoặc Phụ huynh.
          Các trường mặc định bắt buộc của hệ thống (Cơ sở, Phân loại, Mã, Họ tên) không hiển thị ở đây.
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-6">
        {isLoading ? (
          <p className="text-sm text-muted-foreground">Đang tải...</p>
        ) : (
          groups.map(group => {
            const fields = allFields.filter(f => f.group === group);
            if (fields.length === 0) return null;
            return (
              <div key={group} className="space-y-2">
                <h3 className="text-sm font-semibold text-foreground">{CRM_FIELD_GROUP_LABELS[group]}</h3>
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-2">
                  {fields.map((f: CrmConfigurableField) => {
                    const checked = requiredMap.get(f.key) ?? false;
                    return (
                      <label
                        key={f.key}
                        htmlFor={`required-${f.key}`}
                        className={cn(
                          "flex items-center gap-2 px-3 py-2 rounded-md border bg-background hover:bg-muted/40 cursor-pointer",
                          !canEdit && "opacity-60 cursor-not-allowed"
                        )}
                        data-testid={`label-required-${f.key}`}
                      >
                        <Checkbox
                          id={`required-${f.key}`}
                          checked={checked}
                          disabled={!canEdit || upsertMutation.isPending}
                          onCheckedChange={(val) => {
                            if (!canEdit) return;
                            upsertMutation.mutate({ fieldKey: f.key, isRequired: !!val });
                          }}
                          data-testid={`checkbox-required-${f.key}`}
                        />
                        <span className="text-sm text-foreground">{f.label}</span>
                        {checked && <span className="text-destructive text-sm">*</span>}
                      </label>
                    );
                  })}
                </div>
              </div>
            );
          })
        )}
      </CardContent>
    </Card>
  );
}
