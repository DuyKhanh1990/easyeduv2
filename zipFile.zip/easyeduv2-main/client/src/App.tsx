import { lazy, Suspense } from "react";
import { Switch, Route, Redirect } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { TinodeProvider } from "@/hooks/use-tinode";
import { ErrorBoundary } from "@/components/ErrorBoundary";

const NotFound = lazy(() => import("@/pages/not-found"));

const Login = lazy(() => import("@/pages/auth/Login").then(m => ({ default: m.Login })));
const Dashboard = lazy(() => import("@/pages/dashboard/Dashboard").then(m => ({ default: m.Dashboard })));

const CustomersList = lazy(() => import("@/pages/customers/CustomersList").then(m => ({ default: m.CustomersList })));
const CRMConfig = lazy(() => import("@/pages/customers/CRMConfig").then(m => ({ default: m.CRMConfig })));

const StaffList = lazy(() => import("@/pages/staff/StaffList").then(m => ({ default: m.StaffList })));
const ShiftManagement = lazy(() => import("@/pages/shifts/ShiftManagement").then(m => ({ default: m.ShiftManagement })));
const Settings = lazy(() => import("@/pages/settings/Settings").then(m => ({ default: m.Settings })));

const CoursesPrograms = lazy(() => import("@/pages/courses/CoursesPrograms"));
const Assessments = lazy(() => import("@/pages/courses/Assessments"));
const ExamDetail = lazy(() => import("@/pages/courses/ExamDetail").then(m => ({ default: m.ExamDetail })));

const EducationConfig = lazy(() => import("@/pages/education/EducationConfig"));
const ClassList = lazy(() => import("@/pages/education/ClassList").then(m => ({ default: m.ClassList })));
const CreateClass = lazy(() => import("@/pages/education/CreateClass").then(m => ({ default: m.CreateClass })));
const ClassDetail = lazy(() => import("@/pages/education/ClassDetail").then(m => ({ default: m.ClassDetail })));
const Attendance = lazy(() => import("@/pages/education/Attendance").then(m => ({ default: m.Attendance })));
const LearningOverview = lazy(() => import("@/pages/education/learning-overview").then(m => ({ default: m.LearningOverview })));
const Schedule = lazy(() => import("@/pages/education/Schedule").then(m => ({ default: m.Schedule })));

const FinanceConfig = lazy(() => import("@/pages/finance/FinanceConfig"));
const Invoices = lazy(() => import("@/pages/finance/Invoices"));

const MyCalendar = lazy(() => import("@/pages/my-space/MyCalendar"));
const MyAssignments = lazy(() => import("@/pages/my-space/MyAssignments"));
const MyInvoices = lazy(() => import("@/pages/my-space/MyInvoices"));
const MyPayroll = lazy(() => import("@/pages/my-space/MyPayroll"));
const MyScoreSheet = lazy(() => import("@/pages/my-space/MyScoreSheet"));

const TeacherSalary = lazy(() => import("@/pages/hrm/TeacherSalary").then(m => ({ default: m.TeacherSalary })));
const Tasks = lazy(() => import("@/pages/tasks/Tasks"));
const ChatPage = lazy(() => import("@/pages/chat/ChatPage").then(m => ({ default: m.ChatPage })));

const PageLoader = () => (
  <div className="flex h-screen w-full items-center justify-center bg-background">
    <div className="flex flex-col items-center gap-3">
      <div className="w-8 h-8 border-2 border-primary border-t-transparent rounded-full animate-spin" />
      <p className="text-sm text-muted-foreground">Đang tải...</p>
    </div>
  </div>
);

function Router() {
  return (
    <Suspense fallback={<PageLoader />}>
      <Switch>
        <Route path="/login" component={Login} />
        <Route path="/" component={Dashboard} />
        <Route path="/customers" component={CustomersList} />
        <Route path="/customers/crm-config" component={CRMConfig} />
        <Route path="/staff" component={StaffList} />
        <Route path="/shifts" component={ShiftManagement} />
        <Route path="/teacher-salary" component={TeacherSalary} />
        <Route path="/courses" component={CoursesPrograms} />
        <Route path="/programs" component={() => <Redirect to="/courses" />} />
        <Route path="/content-library" component={() => <Redirect to="/courses" />} />
        <Route path="/assessments" component={Assessments} />
        <Route path="/assessments/:id" component={ExamDetail} />
        <Route path="/education-config" component={EducationConfig} />
        <Route path="/classrooms" component={() => <Redirect to="/education-config?tab=classrooms" />} />
        <Route path="/subjects" component={() => <Redirect to="/education-config?tab=subjects" />} />
        <Route path="/evaluation-criteria" component={() => <Redirect to="/education-config?tab=evaluation" />} />
        <Route path="/classes" component={ClassList} />
        <Route path="/classes/create" component={CreateClass} />
        <Route path="/classes/:id" component={ClassDetail} />
        <Route path="/schedule" component={Schedule} />
        <Route path="/learning-overview" component={LearningOverview} />
        <Route path="/attendance" component={Attendance} />
        <Route path="/invoices" component={Invoices} />
        <Route path="/finance-config" component={FinanceConfig} />
        <Route path="/my-space/calendar" component={MyCalendar} />
        <Route path="/my-space/assignments" component={MyAssignments} />
        <Route path="/my-space/score-sheet" component={MyScoreSheet} />
        <Route path="/my-space/invoices" component={MyInvoices} />
        <Route path="/my-space/payroll" component={MyPayroll} />
        <Route path="/tasks" component={Tasks} />
        <Route path="/chat" component={ChatPage} />
        <Route path="/settings" component={Settings} />
        <Route component={NotFound} />
      </Switch>
    </Suspense>
  );
}

function App() {
  return (
    <ErrorBoundary>
      <QueryClientProvider client={queryClient}>
        <TooltipProvider>
          <TinodeProvider>
            <ErrorBoundary>
              <Router />
            </ErrorBoundary>
            <Toaster />
          </TinodeProvider>
        </TooltipProvider>
      </QueryClientProvider>
    </ErrorBoundary>
  );
}

export default App;
